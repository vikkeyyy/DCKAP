<?php

function pages($page,$data){
	$CI =& get_instance();
	if(!empty($page)){
		$CI->load->view('head',$data);
		$CI->load->view('menu',$data);
		$CI->load->view($page,$data);
		$CI->load->view('footer');
		$CI->load->view('script');
	} 
}


?>