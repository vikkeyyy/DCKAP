<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use Google\Client as GoogleClient;
use Google\Service\Oauth2;
class Login extends CI_Controller {
	public function __construct(){
       parent::__construct();
       $this->load->model('Dashboard_model');
    }
	public function index()
	{
		$this->load->view('head');
		$this->load->view('login');
		$this->load->view('footer');
	}
	public function google_login(){
		$client = new GoogleClient();
		$client->setApplicationName('DCKAP Google Login');
		$client->setClientId('953664527172-2kh6gpvlc8fuukhsdm11l6s6ln5d88sk.apps.googleusercontent.com');
		$client->setClientSecret('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');
		$client->setRedirectUri('http://localhost:81/dc_kap/google');
		$client->addScope(['https://www.googleapis.com/auth/userinfo.email','https://www.googleapis.com/auth/userinfo.profile']);

		if($code = $this->input->get('code')){
			$token = $client->fetchAccessTokenWithAuthCode($code);

			$client->setAccessToken($token);
			$oauth = new Oauth2($client);

			$user_info = $oauth->userinfo->get();
			//print_r($user_info);
			$data['name'] = $user_info->name;
			$data['email'] = $user_info->email;
			$data['image'] = $user_info->picture;
			
			$user = $this->Dashboard_model->get_user($user_info->email);
			if(empty($user)){
				$this->Dashboard_model->create_user($data);
			}else{

			}
			// $this->session->set_userdata('users',$user);
			$this->session->set_userdata('email',$user_info->email);
			redirect(base_url('dashboard'));

		}else{
		
		

		$url = $client->createAuthUrl();
		header('Location:'.filter_var($url,FILTER_SANITIZE_URL));
		}

	}
}
