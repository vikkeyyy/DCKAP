<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Dashboard extends MY_Controller {
	public function __construct(){
       parent::__construct();
       $this->load->model('Dashboard_model');
    }
	public function register($id=''){
		if($id!=''){
			$data['users'] = $this->Dashboard_model->get_users($id);
		}	
		$data['countries'] = $this->Dashboard_model->get_tables('countries');
		$data['states'] = $this->Dashboard_model->get_tables('states');
		$data['cities'] = $this->Dashboard_model->get_tables('cities');
		$data['educations'] = $this->Dashboard_model->get_tables('education');
		pages('register',$data);
	}
	public function list_page(){
		$data['registers'] = $this->Dashboard_model->get_tables('register');
		pages('list_page',$data);
	}
	public function filter(){
		$data['registers'] = $this->Dashboard_model->get_tables('register');
		pages('filter',$data);
	}
	public function home(){
		$email =$this->session->userdata('email');;
		$data['users'] = $this->Dashboard_model->get_user($email);
		// print_r($data['users']);
		pages('home',$data);
	}
	
	function change_field(){
		$this->Dashboard_model->change_field();
	}
	function save_register(){
		$this->Dashboard_model->save_register();
	}
	function delete_users(){
		$this->Dashboard_model->delete_user();
	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url(''));
	}
	function view_user($id){
	
		$data['users'] = $this->Dashboard_model->get_users_view($id);
		// print_r($data['users']);
		pages('view',$data);
	}
}
