<?php
class Dashboard_model extends CI_Model{
	public function create_user($data){
		$this->db->insert('users',$data);
	}
	function get_user($mail){
		$data['email'] = $mail;
		$query = $this->db->get_where('users',$data);
		return $query->result();
	}
	function get_tables($table){
		if($table=='register'){
			if($this->input->post('name')!=''){
				$this->db->where('name',$this->input->post('name'));
			}
			if($this->input->post('email')!=''){
				$this->db->where('email',$this->input->post('email'));
			}
			if($this->input->post('age')!=''){
				$this->db->where('age',$this->input->post('age'));
			}
			if($this->input->post('status')!=''){
				$this->db->where('status',$this->input->post('status'));
			}
			$this->db->where('active_status',1);
		}
		$query = $this->db->get($table);
		return $query->result();
	}
	function get_users($id){
		$this->db->where('register_id',$id);
		$query = $this->db->get('register');
		return $query->result();
	}
	function change_field(){
		$data[$this->input->post('column')] = $this->input->post('auto_id');
		$query = $this->db->get_where($this->input->post('table'),$data);
		echo '<option value="">--SELECT--</option>';
		if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
			?>
			 <option value="<?= $row->id ?>"><?= $row->name ?></option>
			<?php	
			}
		}
	}
	function save_register(){
			$config['upload_path']   = 'upload/'; 
	        $config['allowed_types'] = 'jpeg|jpg|png';   
	        $this->load->library('upload', $config);				
	        if ( ! $this->upload->do_upload('profile')) {
	            $error = array('error' => $this->upload->display_errors()); 
	            $file_name = $this->input->post('update_img');
	        }else { 
	            //$data = array('upload_data' => $this->upload->data()); 
	            $upload_data = $this->upload->data();
	            $file_name = 'upload/'.$upload_data['file_name'];          
	        } 
	        //exit;

            $datas['name'] = $this->input->post('name');
            $datas['email'] = $this->input->post('email');
            $datas['address'] = $this->input->post('address');
            $datas['dob'] = $this->input->post('date_of_birth');
            $dateOfBirth = $this->input->post('date_of_birth');
			$today = date("Y-m-d");
			$diff = date_diff(date_create($dateOfBirth), date_create($today));
			$datas['age'] = $diff->format('%y');

            $datas['status'] = $this->input->post('status');
            $datas['education'] = $this->input->post('education');
            $datas['pincode'] = $this->input->post('pincode');
            $datas['profile'] = $file_name;
            $datas['country'] =$this->input->post('country'); 
            $datas['state'] = $this->input->post('state');
            $datas['city'] = $this->input->post('city');
            $update_id = $this->input->post('update_id');

            if($update_id=='0'){
            	$this->db->insert('register',$datas);
            	$this->session->set_userdata('msg',"User Register Successfully");
            	redirect(base_url('list_page'));
            }else{
 				$this->db->where('register_id',$update_id);
 				$this->db->update('register',$datas);
 				redirect(base_url('list_page'));
            }
	}
	function delete_user(){
		$this->db->where('register_id',$this->input->post('user_id'));
		$data['active_status'] = 0;
		$this->db->update('register',$data);
	}
	function get_users_view($id){
		$this->db->where('register_id',$id);
		$this->db->select('register.name,register.email,register.profile,register.address,register.dob,education.education,register.status,register.pincode,countries.name as country_name,states.name as state_name,cities.name as city_name');
		$this->db->from('register');
		$this->db->join('education', 'education.education_id = register.education');
		$this->db->join('countries', 'countries.id = register.country');
		$this->db->join('states', 'states.id = register.state');
		$this->db->join('cities', 'cities.id = register.city');
		$query = $this->db->get();
		return $query->result_array();
	}
	
}
