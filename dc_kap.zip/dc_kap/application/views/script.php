<script type="text/javascript">
	function changeInput(auto_id,table,column,append_id){

		$.ajax({
			url:"<?php echo base_url('change_field') ?>",
			method:"post",
			data:{auto_id:auto_id,table:table,column:column,append_id:append_id},
			success:function(data){
				//console.log(data);
				$('#'+append_id).html(data);
			}
		})
	}
	function deleteUser(id){
		var result = confirm('Are you want to delete user ?');
		if(result){
			$.ajax({
			url:"<?php echo base_url('dashboard/delete_users') ?>",
			method:"POST",
			data:{user_id:id},
			success:function(data){
				location.reload();
			}
		});
		}
	}
</script>