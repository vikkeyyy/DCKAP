

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">List Users</h3>
              </div>
              <!-- /.card-header -->                  
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Profile Pic</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Age</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    if(!empty($registers)){
                      $i=1;
                      foreach ($registers as $key => $row) {
                       
                    ?>
                    <tr>
                      <td><?= $i; ?></td>
                      <td><img src="<?php echo base_url($row->profile); ?>" alt="Girl in a jacket" width="60" height="60"></td>
                      <td><?= $row->name;?></td>
                      <td><?= $row->email;?></td>
                      <td><?= $row->age;?></td>
                      <td><?= $row->status;?></td>
                      <td><a href="<?php echo base_url('Dashboard/view_user/') ?><?= $row->register_id;?>"><button type="button" class="btn btn-primary">View</button></a>&nbsp;&nbsp;<a href="<?php echo base_url('Dashboard/register/')?><?= $row->register_id;?>"><button type="button" class="btn btn-success">Edit</button></a>&nbsp;&nbsp;<button type="button" class="btn btn-danger" onclick="deleteUser(<?= $row->register_id;?>)">Delete</button></td>
                    </tr>
                    <?php $i++; } } ?>
                  </tbody>
                </table>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->





        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

