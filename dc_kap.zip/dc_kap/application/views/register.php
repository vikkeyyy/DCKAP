<?php

if(!empty($users)){
  //print_r($users);
  foreach ($users as $key => $row) {
    $user_id = $row->register_id;
    $name=$row->name;
    $email=$row->email;
    $address=$row->address;
    $dob=$row->dob;
    $status=$row->status;
    $education=$row->education;
    $pincode=$row->pincode;
    $profile=$row->profile;
    $country=$row->country;
    $state=$row->state;
    $city=$row->city;
    // $state=$row->state;
  }
  $btn= "Update";
  $heading = "Register";
}else{
    $user_id = 0;
    $name="";
    $email="";
    $address="";
    $dob="";
    $status="";
    $education="";
    $pincode="";
    $profile="";
    $country="";
    $state="";
    $city="";


  $btn= "Submit";
  $heading = "Update";

}
?> 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- Horizontal Form -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title"><?=$heading ?> Form</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" action="<?php echo base_url('save_register'); ?>" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="update_id" value="<?= $user_id; ?>">
                <input type="hidden" name="update_img" value="<?= $profile; ?>">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
                    <div class="col-sm-10">
                      <input type="name" class="form-control" id="name" name="name" placeholder="" value="<?= $name; ?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="email" name="email" placeholder="" value="<?= $email; ?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Address</label>
                    <div class="col-sm-10">
                      <!-- <input type="email" class="form-control" id="email" name="email" placeholder=""> -->
                      <textarea class="form-control" name="address" required><?= $address; ?></textarea>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Date of Birth</label>
                    <div class="col-sm-10">
                      <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" placeholder="" value="<?= $dob; ?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                      <div class="form-check-inline">
                        <label class="form-check-label">
                          <input type="radio" class="form-check-input" name="status" value="Active" <?php if(!empty($status)){ if($status=='Active'){ echo 'checked'; }} ?>>Active
                        </label>
                      </div>
                      <div class="form-check-inline">
                        <label class="form-check-label">
                          <input type="radio" class="form-check-input" name="status" value="Inactive" <?php if(!empty($status)){ if($status=='Inactive'){ echo 'checked'; }} ?>>Inactive
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Education</label>
                    <div class="col-sm-10">
                     <select class="form-control" id="education" name="education" required>
                      <option value="">--SELECT--</option>
                      <?php 
                      if(!empty($educations)){
                        foreach ($educations as $key => $row) {
                        
                      ?>
                      <option value="<?= $row->education_id ?>" <?php if(!empty($education)){ if($education==$row->education_id){ echo 'selected'; }} ?>><?= $row->education ?></option>
                      <?php } } ?>
                    </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Pincode</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="pincode" name="pincode" placeholder="" value="<?= $pincode; ?>" required>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Profile</label>
                    <div class="col-sm-10">
                      <input type="file" class="form-control" id="profile" name="profile" placeholder="">
                      <?php 
                      if(!empty($profile)){
                        echo '<br>';
                      ?>
                      <img src="<?php echo base_url($profile); ?>" alt="Girl in a jacket" width="60" height="60">
                    <?php } ?>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Country</label>
                    <div class="col-sm-10">
                     <select class="form-control" id="country" name="country" onchange="changeInput(this.value,'states','country_id','state')" required>
                      <option value="">--SELECT--</option>
                      <?php 
                      if(!empty($countries)){
                        foreach ($countries as $key => $row) {
                        
                      ?>
                      <option value="<?= $row->id ?>" <?php if(!empty($country)){ if($country==$row->id){ echo 'selected'; }} ?>><?= $row->name ?></option>
                      <?php } } ?>
                    </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">State</label>
                    <div class="col-sm-10">
                     <select class="form-control" id="state" name="state" onchange="changeInput(this.value,'cities','state_id','city')" required>
                      <?php 
                      if(!empty($state)){
                        foreach ($states as $key => $row) {
                        
                      ?>
                      <option value="<?= $row->id ?>" <?php if(!empty($state)){ if($state==$row->id){ echo 'selected'; }} ?>><?= $row->name ?></option>
                      <?php } } ?>
                      
                    </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">City</label>
                    <div class="col-sm-10">
                     <select class="form-control" id="city" name="city" required>
                      <?php 
                      if(!empty($city)){
                        foreach ($cities as $key => $row) {
                        
                      ?>
                      <option value="<?= $row->id ?>" <?php if(!empty($cities)){ if($cities==$row->id){ echo 'selected'; }} ?>><?= $row->name ?></option>
                      <?php } } ?>
                    </select>
                    </div>
                  </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  
                  <button type="submit" class="btn btn-info float-right"><?= $btn ?></button>
                </div>
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->

          </div>
          <!--/.col (left) -->





        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

